<?php
/**
 * Absensi Siswa Harian
 * File    : index.php
 * Tema    : Hijau / Green
 * Author  : Sistem Informasi Sekolah
 */

/* ── Data Kelas & Mapel ── */
$kelas_list = ['7A','7B','8A','8B','8C','9A','9B'];
$mapel_list = ['Matematika','Bahasa Indonesia','IPA','IPS','Bahasa Inggris','PJOK','Seni Budaya'];

$kelas_aktif = $_GET['kelas'] ?? '8A';
$mapel_aktif = $_GET['mapel'] ?? 'Matematika';

/* ── Data Siswa Kelas 8A (contoh) ── */
$siswa = [
    ['nis'=>'0812345','nama'=>'Ahmad Rizky Pratama', 'status'=>'hadir', 'ket'=>''],
    ['nis'=>'0812346','nama'=>'Bella Sari Dewi',      'status'=>'hadir', 'ket'=>''],
    ['nis'=>'0812347','nama'=>'Cahyo Wibowo',          'status'=>'absen', 'ket'=>''],
    ['nis'=>'0812348','nama'=>'Dewi Rahayu Putri',     'status'=>'izin',  'ket'=>'Acara keluarga'],
    ['nis'=>'0812349','nama'=>'Eko Firmansyah',        'status'=>'hadir', 'ket'=>''],
    ['nis'=>'0812350','nama'=>'Fira Ananda Lestari',   'status'=>'hadir', 'ket'=>''],
    ['nis'=>'0812351','nama'=>'Gilang Prayuda',         'status'=>'sakit', 'ket'=>'Demam'],
    ['nis'=>'0812352','nama'=>'Hana Maharani',          'status'=>'hadir', 'ket'=>''],
    ['nis'=>'0812353','nama'=>'Ivan Setiawan',          'status'=>'hadir', 'ket'=>''],
    ['nis'=>'0812354','nama'=>'Jasmine Putri',          'status'=>'hadir', 'ket'=>''],
    ['nis'=>'0812355','nama'=>'Kevin Ardiansyah',       'status'=>'hadir', 'ket'=>''],
    ['nis'=>'0812356','nama'=>'Lina Suryani',           'status'=>'absen', 'ket'=>''],
];

/* ── Rekap ── */
$hadir  = count(array_filter($siswa, fn($s) => $s['status'] === 'hadir'));
$absen  = count(array_filter($siswa, fn($s) => $s['status'] === 'absen'));
$izin   = count(array_filter($siswa, fn($s) => $s['status'] === 'izin'));
$sakit  = count(array_filter($siswa, fn($s) => $s['status'] === 'sakit'));
$total  = count($siswa);
$persen = $total > 0 ? round($hadir / $total * 100) : 0;

/* ── Rekap Mingguan (dummy) ── */
$rekap_mingguan = [
    'Senin'  => ['hadir'=>30,'absen'=>1,'izin'=>1,'sakit'=>0],
    'Selasa' => ['hadir'=>29,'absen'=>2,'izin'=>0,'sakit'=>1],
    'Rabu'   => ['hadir'=>'–','absen'=>'–','izin'=>'–','sakit'=>'–'],
    'Kamis'  => ['hadir'=>'–','absen'=>'–','izin'=>'–','sakit'=>'–'],
    'Jumat'  => ['hadir'=>'–','absen'=>'–','izin'=>'–','sakit'=>'–'],
];

/* ── Status badge ── */
function badge_s(string $st): string {
    return match($st) {
        'hadir' => '<span class="badge badge-green">Hadir</span>',
        'absen' => '<span class="badge badge-red">Absen</span>',
        'izin'  => '<span class="badge badge-amber">Izin</span>',
        'sakit' => '<span class="badge badge-blue">Sakit</span>',
        default => '<span class="badge badge-gray">—</span>',
    };
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Absensi Siswa — SMP Negeri 1 Contoh</title>
  <link rel="stylesheet" href="../shared.css">
  <style>
    :root {
      --accent       : #16A34A;
      --accent-hover : #15803D;
      --accent-light : rgba(22,163,74,.12);
      --accent-bg    : #F0FDF4;
    }
    .sidebar-brand .brand-icon { background: #DCFCE7; color: #16A34A; }
    .nav-item.active            { background: var(--accent); }
    .topbar-badge { background:#F0FDF4; color:#166534; font-size:11px; font-weight:600; padding:3px 10px; border-radius:99px; }

    /* ── Kelas & Mapel Selectors ── */
    .selector-bar {
      display        : flex;
      gap            : 16px;
      align-items    : center;
      background     : #fff;
      border         : 1px solid var(--gray-100);
      border-radius  : var(--radius-lg);
      padding        : 14px 20px;
      margin-bottom  : 24px;
      flex-wrap      : wrap;
    }
    .selector-group { display:flex; align-items:center; gap:10px; }
    .selector-label { font-size:12px; font-weight:600; color:var(--gray-400); text-transform:uppercase; letter-spacing:.5px; white-space:nowrap; }
    .kelas-pills    { display:flex; gap:5px; flex-wrap:wrap; }
    .kpill {
      padding:5px 12px; border-radius:99px; font-size:12px; font-weight:600;
      cursor:pointer; border:1px solid var(--gray-200); color:var(--gray-500);
      background:#fff; transition:all .15s; text-decoration:none;
    }
    .kpill:hover  { border-color:var(--accent); color:var(--accent); }
    .kpill.active { background:var(--accent); color:#fff; border-color:var(--accent); }

    /* ── Status Toggle di Tabel ── */
    .status-toggle { display:flex; gap:4px; }
    .stog {
      padding:4px 10px; border-radius:99px; font-size:11px; font-weight:600;
      cursor:pointer; border:1px solid var(--gray-200); color:var(--gray-400);
      transition:all .15s; background:#fff; white-space:nowrap;
    }
    .stog:hover { border-color:var(--gray-300); color:var(--gray-600); }
    .stog.h.on  { background:#DCFCE7; color:#166534; border-color:#86EFAC; }
    .stog.a.on  { background:#FEE2E2; color:#991B1B; border-color:#FCA5A5; }
    .stog.i.on  { background:#FEF3C7; color:#92400E; border-color:#FDE68A; }
    .stog.s.on  { background:#DBEAFE; color:#1E40AF; border-color:#93C5FD; }

    /* ── Rekap Mingguan ── */
    .week-table { width:100%; border-collapse:collapse; font-size:12px; }
    .week-table th { padding:8px 12px; font-size:11px; font-weight:600; color:var(--gray-400); text-align:center; background:var(--gray-50); }
    .week-table td { padding:8px 12px; text-align:center; border-top:1px solid var(--gray-100); color:var(--gray-600); }
    .week-table td.day { font-weight:600; color:var(--gray-700); text-align:left; }

    /* ── Kehadiran Meter ── */
    .meter-box { text-align:center; padding:20px; }
    .meter-num { font-size:48px; font-weight:700; color:var(--accent); line-height:1; }
    .meter-lbl { font-size:13px; color:var(--gray-400); margin-top:4px; }
    .meter-bar { height:10px; background:var(--gray-100); border-radius:99px; overflow:hidden; margin:14px 0 8px; }
    .meter-fill { height:100%; background:var(--accent); border-radius:99px; }

    /* ── Two-col ── */
    .two-col { display:grid; grid-template-columns:1fr 280px; gap:20px; align-items:start; }
    @media (max-width:900px) { .two-col { grid-template-columns:1fr; } }
  </style>
</head>
<body>
<div class="page-wrapper">

  <!-- Sidebar -->
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="brand-icon">👥</div>
      <div class="brand-name">SMP Negeri 1 Contoh</div>
      <div class="brand-sub">Sistem Informasi Sekolah</div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section-label">Menu Utama</div>
      <a href="../ppdb/index.php"            class="nav-item"><div class="nav-icon">📋</div> PPDB</a>
      <a href="../perpustakaan/index.php"    class="nav-item"><div class="nav-icon">📚</div> Perpustakaan</a>
      <a href="../absensi-peserta/index.php" class="nav-item"><div class="nav-icon">✅</div> Absensi Peserta</a>
      <a href="../pembayaran-spp/index.php"  class="nav-item"><div class="nav-icon">💳</div> Pembayaran SPP</a>
      <a href="index.php"                    class="nav-item active"><div class="nav-icon">👥</div> Absensi Siswa</a>
    </nav>
    <div class="sidebar-footer">v1.0.0 &nbsp;·&nbsp; TP 2025/2026</div>
  </aside>

  <!-- Konten -->
  <div class="main-content">
    <header class="topbar">
      <div class="topbar-title">Absensi Siswa Harian</div>
      <div class="topbar-right">
        <span class="topbar-badge">Kelas <?= htmlspecialchars($kelas_aktif) ?></span>
        <span class="topbar-date"><?= date('l, d M Y') ?></span>
        <div class="avatar-sm" style="background:#DCFCE7;color:#16A34A;">GR</div>
      </div>
    </header>

    <div class="page-body">
      <div class="page-header flex items-center justify-between">
        <div>
          <h1 class="page-title">Rekam Kehadiran Siswa</h1>
          <p class="page-subtitle">Absensi harian per kelas dan mata pelajaran — Rabu, <?= date('d M Y') ?></p>
        </div>
        <div class="flex gap-2">
          <button class="btn btn-ghost">⬇ Export Rekap</button>
          <button class="btn btn-primary" style="background:var(--accent)">💾 Simpan & Kirim</button>
        </div>
      </div>

      <!-- Selector Kelas & Mapel -->
      <div class="selector-bar">
        <div class="selector-group">
          <span class="selector-label">Kelas:</span>
          <div class="kelas-pills">
            <?php foreach ($kelas_list as $kl): ?>
            <a href="?kelas=<?= urlencode($kl) ?>&mapel=<?= urlencode($mapel_aktif) ?>"
               class="kpill <?= $kelas_aktif===$kl?'active':'' ?>"><?= $kl ?></a>
            <?php endforeach; ?>
          </div>
        </div>
        <div style="width:1px;height:28px;background:var(--gray-200);margin:0 4px;flex-shrink:0"></div>
        <div class="selector-group">
          <span class="selector-label">Mapel:</span>
          <select class="form-control" style="width:auto"
                  onchange="location='?kelas=<?= urlencode($kelas_aktif) ?>&mapel='+this.value">
            <?php foreach ($mapel_list as $mp): ?>
            <option value="<?= htmlspecialchars($mp) ?>" <?= $mapel_aktif===$mp?'selected':'' ?>>
              <?= htmlspecialchars($mp) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <!-- Statistik -->
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon" style="background:#DCFCE7;color:#166534;">✅</div>
          <div class="stat-label">Hadir</div>
          <div class="stat-value" style="color:#166534"><?= $hadir ?></div>
          <div class="stat-desc"><?= $persen ?>% kehadiran</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#FEE2E2;color:#991B1B;">✗</div>
          <div class="stat-label">Absen / Alfa</div>
          <div class="stat-value" style="color:#991B1B"><?= $absen ?></div>
          <div class="stat-desc">Tanpa keterangan</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#FEF3C7;color:#92400E;">📝</div>
          <div class="stat-label">Izin</div>
          <div class="stat-value" style="color:#92400E"><?= $izin ?></div>
          <div class="stat-desc">Ada surat izin</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#DBEAFE;color:#1E40AF;">🏥</div>
          <div class="stat-label">Sakit</div>
          <div class="stat-value" style="color:#1E40AF"><?= $sakit ?></div>
          <div class="stat-desc">Ada surat dokter</div>
        </div>
      </div>

      <div class="two-col">
        <!-- Tabel Absensi -->
        <div class="table-wrapper">
          <div class="table-header">
            <span class="table-title">
              Kelas <?= htmlspecialchars($kelas_aktif) ?> — <?= htmlspecialchars($mapel_aktif) ?>
            </span>
            <div class="search-wrapper">
              <span class="search-icon">🔍</span>
              <input type="text" class="search-input" placeholder="Cari nama siswa...">
            </div>
          </div>
          <table>
            <thead>
              <tr><th>#</th><th>NIS</th><th>Nama Siswa</th><th>Status</th><th>Keterangan</th><th>Ubah</th></tr>
            </thead>
            <tbody>
            <?php foreach ($siswa as $i => $s): ?>
            <tr>
              <td class="text-muted text-sm"><?= $i + 1 ?></td>
              <td><span style="font-family:var(--font-mono);font-size:11px;color:var(--gray-400)"><?= $s['nis'] ?></span></td>
              <td class="td-main"><?= htmlspecialchars($s['nama']) ?></td>
              <td><?= badge_s($s['status']) ?></td>
              <td class="text-muted text-sm"><?= $s['ket'] ?: '—' ?></td>
              <td>
                <div class="status-toggle">
                  <button class="stog h <?= $s['status']==='hadir'?'on':'' ?>" title="Hadir">H</button>
                  <button class="stog a <?= $s['status']==='absen'?'on':'' ?>" title="Absen">A</button>
                  <button class="stog i <?= $s['status']==='izin' ?'on':'' ?>" title="Izin">I</button>
                  <button class="stog s <?= $s['status']==='sakit'?'on':'' ?>" title="Sakit">S</button>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <div class="pagination">
            <div class="page-info">Total <?= $total ?> siswa terdaftar</div>
            <button class="btn btn-primary btn-sm" style="background:var(--accent);margin-left:auto">
              💾 Simpan Absensi
            </button>
          </div>
        </div>

        <!-- Kolom Kanan -->
        <div>
          <!-- Meter Kehadiran -->
          <div class="card" style="margin-bottom:16px">
            <div class="card-header">Kehadiran Hari Ini</div>
            <div class="meter-box">
              <div class="meter-num"><?= $persen ?>%</div>
              <div class="meter-lbl">Tingkat kehadiran</div>
              <div class="meter-bar">
                <div class="meter-fill" style="width:<?= $persen ?>%"></div>
              </div>
              <div style="font-size:12px;color:var(--gray-400)"><?= $hadir ?> hadir dari <?= $total ?> siswa</div>
            </div>
          </div>

          <!-- Rekap Mingguan -->
          <div class="card">
            <div class="card-header">Rekap Mingguan</div>
            <table class="week-table">
              <thead>
                <tr><th style="text-align:left">Hari</th><th>H</th><th>A</th><th>I</th><th>S</th></tr>
              </thead>
              <tbody>
              <?php foreach ($rekap_mingguan as $hari => $r): ?>
              <tr>
                <td class="day"><?= $hari ?></td>
                <td style="color:#166534;font-weight:600"><?= $r['hadir'] ?></td>
                <td style="color:#991B1B;font-weight:600"><?= $r['absen'] ?></td>
                <td style="color:#92400E;font-weight:600"><?= $r['izin'] ?></td>
                <td style="color:#1E40AF;font-weight:600"><?= $r['sakit'] ?></td>
              </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>

          <!-- Notifikasi ke Ortu -->
          <div class="alert alert-info mt-4">
            📲 <span><strong>2 siswa absen</strong> — notifikasi WhatsApp ke orang tua akan dikirim otomatis setelah absensi disimpan.</span>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
</body>
</html>
