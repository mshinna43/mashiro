<?php
/**
 * Pembayaran SPP — School Fee Payment
 * File    : index.php
 * Tema    : Amber / Kuning-Coklat
 * Author  : Sistem Informasi Sekolah
 */

/* ── Data Tagihan Siswa ── */
$tagihan = [
    ['nis'=>'0812345','nama'=>'Ahmad Rizky Pratama','kelas'=>'8A','bulan'=>'Juni 2025',  'nominal'=>350000,'status'=>'belum','jatuh_tempo'=>'30 Jun 2025'],
    ['nis'=>'0812346','nama'=>'Bella Sari Dewi',     'kelas'=>'8A','bulan'=>'Juni 2025',  'nominal'=>350000,'status'=>'lunas','jatuh_tempo'=>'30 Jun 2025'],
    ['nis'=>'0812347','nama'=>'Cahyo Wibowo',         'kelas'=>'8B','bulan'=>'Juni 2025',  'nominal'=>350000,'status'=>'belum','jatuh_tempo'=>'30 Jun 2025'],
    ['nis'=>'0812348','nama'=>'Dewi Rahayu Putri',    'kelas'=>'8B','bulan'=>'Mei 2025',   'nominal'=>350000,'status'=>'menunggak','jatuh_tempo'=>'31 Mei 2025'],
    ['nis'=>'0812349','nama'=>'Eko Firmansyah',       'kelas'=>'8C','bulan'=>'Juni 2025',  'nominal'=>350000,'status'=>'lunas','jatuh_tempo'=>'30 Jun 2025'],
    ['nis'=>'0812350','nama'=>'Fira Ananda Lestari',  'kelas'=>'8A','bulan'=>'Mei 2025',   'nominal'=>350000,'status'=>'menunggak','jatuh_tempo'=>'31 Mei 2025'],
    ['nis'=>'0812351','nama'=>'Gilang Prayuda',        'kelas'=>'9A','bulan'=>'Juni 2025',  'nominal'=>375000,'status'=>'lunas','jatuh_tempo'=>'30 Jun 2025'],
    ['nis'=>'0812352','nama'=>'Hana Maharani',         'kelas'=>'9B','bulan'=>'Juni 2025',  'nominal'=>375000,'status'=>'belum','jatuh_tempo'=>'30 Jun 2025'],
    ['nis'=>'0812353','nama'=>'Ivan Setiawan',         'kelas'=>'7A','bulan'=>'Juni 2025',  'nominal'=>325000,'status'=>'lunas','jatuh_tempo'=>'30 Jun 2025'],
    ['nis'=>'0812354','nama'=>'Jasmine Putri',         'kelas'=>'7B','bulan'=>'April 2025', 'nominal'=>325000,'status'=>'menunggak','jatuh_tempo'=>'30 Apr 2025'],
];

/* ── Filter ── */
$filter = $_GET['status'] ?? 'semua';
$search = strtolower(trim($_GET['q'] ?? ''));

$filtered = array_filter($tagihan, function($t) use ($filter, $search) {
    $ms = ($filter === 'semua') || ($t['status'] === $filter);
    $mq = empty($search) || str_contains(strtolower($t['nama']), $search)
                         || str_contains(strtolower($t['nis']), $search);
    return $ms && $mq;
});

/* ── Statistik Keuangan ── */
$lunas      = array_filter($tagihan, fn($t) => $t['status'] === 'lunas');
$belum      = array_filter($tagihan, fn($t) => $t['status'] === 'belum');
$menunggak  = array_filter($tagihan, fn($t) => $t['status'] === 'menunggak');
$total_masuk   = array_sum(array_column(iterator_to_array((function() use ($lunas) { foreach($lunas as $v) yield $v; })()), 'nominal'));
$total_belum   = array_sum(array_column(iterator_to_array((function() use ($belum,$menunggak) { foreach(array_merge($belum,$menunggak) as $v) yield $v; })()), 'nominal'));

/* ── Format Rupiah ── */
function rupiah(int $n): string { return 'Rp ' . number_format($n, 0, ',', '.'); }

/* ── Badge Status ── */
function badge_spp(string $status): string {
    return match($status) {
        'lunas'     => '<span class="badge badge-green">Lunas</span>',
        'belum'     => '<span class="badge badge-amber">Belum Bayar</span>',
        'menunggak' => '<span class="badge badge-red">Menunggak</span>',
        default     => '<span class="badge badge-gray">—</span>',
    };
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pembayaran SPP — SMP Negeri 1 Contoh</title>
  <link rel="stylesheet" href="../shared.css">
  <style>
    :root {
      --accent       : #D97706;
      --accent-hover : #B45309;
      --accent-light : rgba(217,119,6,.12);
      --accent-bg    : #FFFBEB;
    }
    .sidebar-brand .brand-icon { background: #FEF3C7; color: #D97706; }
    .nav-item.active            { background: var(--accent); }
    .topbar-badge { background:#FFFBEB; color:#92400E; font-size:11px; font-weight:600; padding:3px 10px; border-radius:99px; }

    /* ── Summary Banner ── */
    .summary-banner {
      display               : grid;
      grid-template-columns : 1fr 1fr;
      gap                   : 16px;
      margin-bottom         : 28px;
    }
    .sum-card {
      border-radius : var(--radius-lg);
      padding       : 22px 24px;
      color         : #fff;
    }
    .sum-card.green  { background: #16A34A; }
    .sum-card.amber  { background: #D97706; }
    .sum-label { font-size:12px; font-weight:600; opacity:.75; text-transform:uppercase; letter-spacing:.5px; }
    .sum-value { font-size:26px; font-weight:700; margin:6px 0 2px; }
    .sum-sub   { font-size:12px; opacity:.7; }

    /* ── Metode Pembayaran ── */
    .metode-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:8px; margin-bottom:16px; }
    .metode-btn {
      padding:10px; text-align:center; border-radius:var(--radius-md);
      border:1px solid var(--gray-200); background:#fff; cursor:pointer;
      font-size:12px; font-weight:600; color:var(--gray-600);
      transition:all .15s;
    }
    .metode-btn:hover { border-color:var(--accent); color:var(--accent); }
    .metode-btn.selected { border-color:var(--accent); background:var(--accent-bg); color:var(--accent); }

    /* ── Filter Pills ── */
    .pill { padding:6px 14px; border-radius:99px; font-size:12px; font-weight:600; cursor:pointer; border:1px solid var(--gray-200); color:var(--gray-500); background:#fff; transition:all .15s; text-decoration:none; }
    .pill:hover  { border-color:var(--accent); color:var(--accent); }
    .pill.active { background:var(--accent); color:#fff; border-color:var(--accent); }

    /* ── Two-col ── */
    .two-col { display:grid; grid-template-columns:1fr 300px; gap:20px; align-items:start; }
    @media (max-width:900px) { .two-col { grid-template-columns:1fr; } }
    @media (max-width:600px) { .summary-banner { grid-template-columns:1fr; } }
  </style>
</head>
<body>
<div class="page-wrapper">

  <!-- Sidebar -->
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="brand-icon">💳</div>
      <div class="brand-name">SMP Negeri 1 Contoh</div>
      <div class="brand-sub">Sistem Informasi Sekolah</div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section-label">Menu Utama</div>
      <a href="../ppdb/index.php"            class="nav-item"><div class="nav-icon">📋</div> PPDB</a>
      <a href="../perpustakaan/index.php"    class="nav-item"><div class="nav-icon">📚</div> Perpustakaan</a>
      <a href="../absensi-peserta/index.php" class="nav-item"><div class="nav-icon">✅</div> Absensi Peserta</a>
      <a href="index.php"                    class="nav-item active"><div class="nav-icon">💳</div> Pembayaran SPP</a>
      <a href="../absensi-siswa/index.php"   class="nav-item"><div class="nav-icon">👥</div> Absensi Siswa</a>
    </nav>
    <div class="sidebar-footer">v1.0.0 &nbsp;·&nbsp; TP 2025/2026</div>
  </aside>

  <!-- Konten -->
  <div class="main-content">
    <header class="topbar">
      <div class="topbar-title">Pembayaran SPP</div>
      <div class="topbar-right">
        <span class="topbar-badge">Juni 2025</span>
        <span class="topbar-date"><?= date('d M Y') ?></span>
        <div class="avatar-sm" style="background:#FEF3C7;color:#D97706;">BU</div>
      </div>
    </header>

    <div class="page-body">
      <div class="page-header flex items-center justify-between">
        <div>
          <h1 class="page-title">Kelola Pembayaran SPP</h1>
          <p class="page-subtitle">Tagihan, status pembayaran, dan rekap keuangan sekolah</p>
        </div>
        <div class="flex gap-2">
          <button class="btn btn-ghost">⬇ Laporan PDF</button>
          <button class="btn btn-primary" style="background:var(--accent)">+ Catat Pembayaran</button>
        </div>
      </div>

      <!-- Summary Banner -->
      <div class="summary-banner">
        <div class="sum-card green">
          <div class="sum-label">Total Terbayar</div>
          <div class="sum-value"><?= rupiah($total_masuk) ?></div>
          <div class="sum-sub"><?= count($lunas) ?> siswa sudah lunas</div>
        </div>
        <div class="sum-card amber">
          <div class="sum-label">Belum / Menunggak</div>
          <div class="sum-value"><?= rupiah($total_belum) ?></div>
          <div class="sum-sub"><?= count($belum) + count($menunggak) ?> siswa perlu ditindak</div>
        </div>
      </div>

      <!-- Statistik -->
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon" style="background:#FEF3C7;color:#92400E;">💳</div>
          <div class="stat-label">Total Siswa</div>
          <div class="stat-value" style="color:#D97706"><?= count($tagihan) ?></div>
          <div class="stat-desc">Semua kelas</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#DCFCE7;color:#166534;">✅</div>
          <div class="stat-label">Lunas</div>
          <div class="stat-value" style="color:#166534"><?= count($lunas) ?></div>
          <div class="stat-desc">Sudah membayar</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#FEF3C7;color:#92400E;">⏳</div>
          <div class="stat-label">Belum Bayar</div>
          <div class="stat-value" style="color:#D97706"><?= count($belum) ?></div>
          <div class="stat-desc">Dalam periode aktif</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#FEE2E2;color:#991B1B;">⚠️</div>
          <div class="stat-label">Menunggak</div>
          <div class="stat-value" style="color:#991B1B"><?= count($menunggak) ?></div>
          <div class="stat-desc">Melewati jatuh tempo</div>
        </div>
      </div>

      <div class="two-col">
        <!-- Tabel Tagihan -->
        <div class="table-wrapper">
          <div class="table-header">
            <span class="table-title">Daftar Tagihan Siswa</span>
            <div class="flex gap-3 items-center flex-wrap">
              <div style="display:flex;gap:6px;flex-wrap:wrap">
                <?php
                $pills = ['semua'=>'Semua','lunas'=>'Lunas','belum'=>'Belum Bayar','menunggak'=>'Menunggak'];
                foreach ($pills as $v => $l):
                  $a = $filter===$v?'active':'';
                ?>
                <a href="?status=<?= $v ?>&q=<?= htmlspecialchars($search) ?>" class="pill <?= $a ?>"><?= $l ?></a>
                <?php endforeach; ?>
              </div>
              <form method="GET" style="display:contents">
                <input type="hidden" name="status" value="<?= htmlspecialchars($filter) ?>">
                <div class="search-wrapper">
                  <span class="search-icon">🔍</span>
                  <input type="text" name="q" class="search-input" placeholder="Cari nama / NIS..."
                         value="<?= htmlspecialchars($search) ?>">
                </div>
              </form>
            </div>
          </div>
          <table>
            <thead>
              <tr><th>NIS</th><th>Nama Siswa</th><th>Kelas</th><th>Bulan</th><th>Nominal</th><th>Jatuh Tempo</th><th>Status</th><th>Aksi</th></tr>
            </thead>
            <tbody>
            <?php if (empty($filtered)): ?>
              <tr><td colspan="8" style="text-align:center;padding:40px;color:var(--gray-400)">Tidak ada data.</td></tr>
            <?php else: ?>
              <?php foreach ($filtered as $t): ?>
              <tr>
                <td><span style="font-family:var(--font-mono);font-size:11px;color:var(--gray-400)"><?= $t['nis'] ?></span></td>
                <td class="td-main"><?= htmlspecialchars($t['nama']) ?></td>
                <td><span class="badge badge-gray"><?= $t['kelas'] ?></span></td>
                <td class="text-sm"><?= $t['bulan'] ?></td>
                <td><strong style="font-family:var(--font-mono)"><?= rupiah($t['nominal']) ?></strong></td>
                <td class="text-muted text-sm"><?= $t['jatuh_tempo'] ?></td>
                <td><?= badge_spp($t['status']) ?></td>
                <td>
                  <?php if ($t['status'] !== 'lunas'): ?>
                  <button class="btn btn-primary btn-sm" style="background:var(--accent)">Bayar</button>
                  <?php else: ?>
                  <button class="btn btn-ghost btn-sm">Struk</button>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
          </table>
          <div class="pagination">
            <div class="page-btn active">1</div>
            <div class="page-btn">2</div>
            <div class="page-info">Menampilkan <?= count($filtered) ?> dari <?= count($tagihan) ?> data</div>
          </div>
        </div>

        <!-- Kolom Kanan: Form Catat Pembayaran -->
        <div class="card">
          <div class="card-header">💳 Catat Pembayaran Baru</div>
          <div class="card-body">
            <div class="form-group">
              <label class="form-label">NIS / Nama Siswa</label>
              <input type="text" class="form-control" placeholder="Cari siswa...">
            </div>
            <div class="form-group">
              <label class="form-label">Bulan Pembayaran</label>
              <select class="form-control">
                <option>Juni 2025</option>
                <option>Juli 2025</option>
                <option>Agustus 2025</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Nominal</label>
              <input type="text" class="form-control" value="Rp 350.000" readonly
                     style="background:var(--gray-50);color:var(--gray-500)">
            </div>
            <div class="form-group">
              <label class="form-label">Metode Pembayaran</label>
              <div class="metode-grid">
                <div class="metode-btn selected">🏧 Tunai</div>
                <div class="metode-btn">🏦 Transfer</div>
                <div class="metode-btn">📱 E-Wallet</div>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Catatan (opsional)</label>
              <textarea class="form-control" rows="2" placeholder="Keterangan tambahan..."></textarea>
            </div>
            <button class="btn btn-primary w-full" style="background:var(--accent);justify-content:center">
              Simpan Pembayaran
            </button>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
</body>
</html>
