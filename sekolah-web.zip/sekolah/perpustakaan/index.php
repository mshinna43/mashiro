<?php
/**
 * Perpustakaan Digital Sekolah
 * File    : index.php
 * Tema    : Teal / Hijau
 * Author  : Sistem Informasi Sekolah
 */

/* ── Data Koleksi Buku ── */
$buku = [
    ['id'=>'BK001','judul'=>'Laskar Pelangi',        'penulis'=>'Andrea Hirata',    'kategori'=>'Novel',  'stok'=>5, 'dipinjam'=>3,'isbn'=>'978-602-14-1234-5'],
    ['id'=>'BK002','judul'=>'Negeri 5 Menara',        'penulis'=>'Ahmad Fuadi',      'kategori'=>'Novel',  'stok'=>3, 'dipinjam'=>3,'isbn'=>'978-602-14-2234-5'],
    ['id'=>'BK003','judul'=>'Bumi (Tere Liye)',       'penulis'=>'Tere Liye',        'kategori'=>'Fiksi',  'stok'=>6, 'dipinjam'=>2,'isbn'=>'978-602-14-3234-5'],
    ['id'=>'BK004','judul'=>'Matematika Kelas 8',     'penulis'=>'Kemendikbud',      'kategori'=>'Pelajaran','stok'=>20,'dipinjam'=>15,'isbn'=>'978-602-14-4234-5'],
    ['id'=>'BK005','judul'=>'IPA Terpadu Kelas 7',    'penulis'=>'Tim Penulis',      'kategori'=>'Pelajaran','stok'=>18,'dipinjam'=>10,'isbn'=>'978-602-14-5234-5'],
    ['id'=>'BK006','judul'=>'Sejarah Indonesia',      'penulis'=>'Sartono Kartodirdjo','kategori'=>'Sejarah','stok'=>8, 'dipinjam'=>4,'isbn'=>'978-602-14-6234-5'],
    ['id'=>'BK007','judul'=>'Kamus Besar Bahasa Indonesia','penulis'=>'Pusat Bahasa','kategori'=>'Referensi','stok'=>4,'dipinjam'=>1,'isbn'=>'978-602-14-7234-5'],
    ['id'=>'BK008','judul'=>'Harry Potter (Ind.)',    'penulis'=>'J.K. Rowling',     'kategori'=>'Fiksi',  'stok'=>3, 'dipinjam'=>3,'isbn'=>'978-602-14-8234-5'],
];

/* ── Data Peminjaman Aktif ── */
$peminjaman = [
    ['nis'=>'0812345','nama'=>'Ahmad Rizky',    'buku'=>'Laskar Pelangi',    'tgl_pinjam'=>'10 Jun','tgl_kembali'=>'24 Jun','status'=>'aktif'],
    ['nis'=>'0812346','nama'=>'Bella Dewi',     'buku'=>'Bumi (Tere Liye)',  'tgl_pinjam'=>'12 Jun','tgl_kembali'=>'26 Jun','status'=>'aktif'],
    ['nis'=>'0812347','nama'=>'Cahyo Wibowo',   'buku'=>'Negeri 5 Menara',  'tgl_pinjam'=>'08 Jun','tgl_kembali'=>'22 Jun','status'=>'terlambat'],
    ['nis'=>'0812348','nama'=>'Dewi Rahayu',    'buku'=>'Harry Potter',      'tgl_pinjam'=>'14 Jun','tgl_kembali'=>'28 Jun','status'=>'aktif'],
    ['nis'=>'0812349','nama'=>'Eko Firmansyah', 'buku'=>'Sejarah Indonesia', 'tgl_pinjam'=>'05 Jun','tgl_kembali'=>'19 Jun','status'=>'terlambat'],
];

/* ── Filter & Statistik ── */
$filter_kat = $_GET['kat'] ?? 'semua';
$search     = strtolower(trim($_GET['q'] ?? ''));

$filtered = array_filter($buku, function($b) use ($filter_kat, $search) {
    $match_kat    = ($filter_kat === 'semua') || ($b['kategori'] === $filter_kat);
    $match_search = empty($search) || str_contains(strtolower($b['judul']), $search)
                                   || str_contains(strtolower($b['penulis']), $search);
    return $match_kat && $match_search;
});

$total_buku     = count($buku);
$total_pinjam   = count($peminjaman);
$terlambat      = count(array_filter($peminjaman, fn($p) => $p['status'] === 'terlambat'));
$kategori_list  = array_unique(array_column($buku, 'kategori'));

/* ── Helper: stok badge ── */
function badge_stok(int $stok, int $dipinjam): string {
    $sisa = $stok - $dipinjam;
    if ($sisa === 0)   return '<span class="badge badge-red">Habis</span>';
    if ($sisa <= 2)    return '<span class="badge badge-amber">Sisa '.$sisa.'</span>';
    return '<span class="badge badge-green">Tersedia '.$sisa.'</span>';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Perpustakaan — SMP Negeri 1 Contoh</title>
  <link rel="stylesheet" href="../shared.css">
  <style>
    /* ── Tema Teal ── */
    :root {
      --accent       : #0D9488;
      --accent-hover : #0F766E;
      --accent-light : rgba(13,148,136,.12);
      --accent-bg    : #F0FDFA;
    }
    .sidebar-brand .brand-icon { background: #CCFBF1; color: #0D9488; }
    .nav-item.active            { background: var(--accent); }
    .stat-icon-teal             { background: #CCFBF1; color: #0D9488; }
    .stat-value-teal            { color: #0D9488; }
    .topbar-badge { background:#F0FDFA; color:#0D9488; font-size:11px; font-weight:600; padding:3px 10px; border-radius:99px; }

    /* ── Buku Grid Cards ── */
    .book-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; margin-bottom: 28px; }
    .book-card {
      background    : #fff;
      border-radius : var(--radius-lg);
      border        : 1px solid var(--gray-100);
      overflow      : hidden;
      transition    : box-shadow var(--transition), transform var(--transition);
      cursor        : pointer;
    }
    .book-card:hover { box-shadow: var(--shadow-md); transform: translateY(-2px); }
    .book-cover {
      height         : 80px;
      display        : flex;
      align-items    : center;
      justify-content: center;
      font-size      : 32px;
    }
    .book-info { padding: 12px; }
    .book-title { font-size: 13px; font-weight: 600; color: var(--gray-800); line-height: 1.3; margin-bottom: 3px; }
    .book-author { font-size: 11px; color: var(--gray-400); margin-bottom: 8px; }

    /* ── Peminjaman Banner ── */
    .terlambat-alert {
      background    : #FEF2F2;
      border        : 1px solid #FECACA;
      border-radius : var(--radius-md);
      padding       : 12px 16px;
      margin-bottom : 16px;
      font-size     : 13px;
      color         : #991B1B;
      display       : flex;
      align-items   : center;
      gap           : 8px;
    }
    /* ── Two-col layout ── */
    .two-col { display: grid; grid-template-columns: 1fr 340px; gap: 20px; align-items: start; }
    @media (max-width: 900px) { .two-col { grid-template-columns: 1fr; } }

    /* ── Filter Pills ── */
    .pill { padding:6px 14px; border-radius:99px; font-size:12px; font-weight:600; cursor:pointer; border:1px solid var(--gray-200); color:var(--gray-500); background:#fff; transition:all .15s; text-decoration:none; }
    .pill:hover  { border-color:var(--accent); color:var(--accent); }
    .pill.active { background:var(--accent); color:#fff; border-color:var(--accent); }
  </style>
</head>
<body>
<div class="page-wrapper">

  <!-- ═══ Sidebar ═══ -->
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="brand-icon">📚</div>
      <div class="brand-name">SMP Negeri 1 Contoh</div>
      <div class="brand-sub">Sistem Informasi Sekolah</div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section-label">Menu Utama</div>
      <a href="../ppdb/index.php"            class="nav-item"><div class="nav-icon">📋</div> PPDB</a>
      <a href="index.php"                    class="nav-item active"><div class="nav-icon">📚</div> Perpustakaan</a>
      <a href="../absensi-peserta/index.php" class="nav-item"><div class="nav-icon">✅</div> Absensi Peserta</a>
      <a href="../pembayaran-spp/index.php"  class="nav-item"><div class="nav-icon">💳</div> Pembayaran SPP</a>
      <a href="../absensi-siswa/index.php"   class="nav-item"><div class="nav-icon">👥</div> Absensi Siswa</a>
    </nav>
    <div class="sidebar-footer">v1.0.0 &nbsp;·&nbsp; TP 2025/2026</div>
  </aside>

  <!-- ═══ Konten ═══ -->
  <div class="main-content">
    <header class="topbar">
      <div class="topbar-title">Perpustakaan Digital</div>
      <div class="topbar-right">
        <span class="topbar-badge">📚 <?= $total_buku ?> Koleksi</span>
        <span class="topbar-date"><?= date('d M Y') ?></span>
        <div class="avatar-sm" style="background:#CCFBF1;color:#0D9488;">PU</div>
      </div>
    </header>

    <div class="page-body">
      <div class="page-header flex items-center justify-between">
        <div>
          <h1 class="page-title">Katalog & Peminjaman</h1>
          <p class="page-subtitle">Kelola koleksi buku dan data peminjaman siswa</p>
        </div>
        <button class="btn btn-primary" style="background:var(--accent)">+ Tambah Buku</button>
      </div>

      <!-- Statistik -->
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon stat-icon-teal">📖</div>
          <div class="stat-label">Total Koleksi</div>
          <div class="stat-value stat-value-teal"><?= $total_buku ?></div>
          <div class="stat-desc">Judul buku</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#DBEAFE;color:#1E40AF;">🔄</div>
          <div class="stat-label">Dipinjam</div>
          <div class="stat-value" style="color:#1E40AF"><?= $total_pinjam ?></div>
          <div class="stat-desc">Aktif dipinjam</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#FEE2E2;color:#991B1B;">⚠️</div>
          <div class="stat-label">Terlambat</div>
          <div class="stat-value" style="color:#991B1B"><?= $terlambat ?></div>
          <div class="stat-desc">Melewati batas kembali</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#EDE9FE;color:#5B21B6;">🗂️</div>
          <div class="stat-label">Kategori</div>
          <div class="stat-value" style="color:#5B21B6"><?= count($kategori_list) ?></div>
          <div class="stat-desc">Jenis koleksi</div>
        </div>
      </div>

      <?php if ($terlambat > 0): ?>
      <div class="terlambat-alert">
        ⚠️ <strong><?= $terlambat ?> peminjaman</strong> melewati batas waktu pengembalian. Segera hubungi siswa terkait.
      </div>
      <?php endif; ?>

      <div class="two-col">
        <!-- Kolom Kiri: Katalog -->
        <div>
          <!-- Filter & Search -->
          <div class="table-header" style="background:#fff;border-radius:var(--radius-lg) var(--radius-lg) 0 0;border:1px solid var(--gray-100);border-bottom:none">
            <div class="flex gap-2 flex-wrap items-center" style="flex-wrap:wrap;gap:8px">
              <a href="?kat=semua&q=<?= htmlspecialchars($search) ?>" class="pill <?= $filter_kat==='semua'?'active':'' ?>">Semua</a>
              <?php foreach ($kategori_list as $kat): ?>
              <a href="?kat=<?= urlencode($kat) ?>&q=<?= htmlspecialchars($search) ?>"
                 class="pill <?= $filter_kat===$kat?'active':'' ?>"><?= htmlspecialchars($kat) ?></a>
              <?php endforeach; ?>
            </div>
            <form method="GET" style="display:contents">
              <input type="hidden" name="kat" value="<?= htmlspecialchars($filter_kat) ?>">
              <div class="search-wrapper">
                <span class="search-icon">🔍</span>
                <input type="text" name="q" class="search-input" placeholder="Cari judul / penulis..."
                       value="<?= htmlspecialchars($search) ?>">
              </div>
            </form>
          </div>

          <div class="table-wrapper" style="border-top:0;border-radius:0 0 var(--radius-lg) var(--radius-lg)">
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Judul Buku</th><th>Penulis</th><th>Kategori</th><th>Stok</th><th>Aksi</th>
                </tr>
              </thead>
              <tbody>
              <?php foreach ($filtered as $b): ?>
              <tr>
                <td><span style="font-family:var(--font-mono);font-size:11px;color:var(--gray-400)"><?= $b['id'] ?></span></td>
                <td class="td-main"><?= htmlspecialchars($b['judul']) ?></td>
                <td class="text-muted text-sm"><?= htmlspecialchars($b['penulis']) ?></td>
                <td><span class="badge badge-teal"><?= $b['kategori'] ?></span></td>
                <td><?= badge_stok($b['stok'], $b['dipinjam']) ?></td>
                <td><button class="btn btn-ghost btn-sm">Pinjam</button></td>
              </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Kolom Kanan: Peminjaman Aktif -->
        <div class="card">
          <div class="card-header">🔄 Peminjaman Aktif</div>
          <div style="padding:0">
            <?php foreach ($peminjaman as $p): ?>
            <div style="padding:12px 16px;border-bottom:1px solid var(--gray-100)">
              <div class="flex justify-between items-center mb-4">
                <div>
                  <div style="font-size:13px;font-weight:600;color:var(--gray-800)"><?= htmlspecialchars($p['nama']) ?></div>
                  <div style="font-size:11px;color:var(--gray-400);font-family:var(--font-mono)"><?= $p['nis'] ?></div>
                </div>
                <?php if ($p['status'] === 'terlambat'): ?>
                  <span class="badge badge-red">Terlambat</span>
                <?php else: ?>
                  <span class="badge badge-green">Aktif</span>
                <?php endif; ?>
              </div>
              <div style="font-size:12px;color:var(--gray-500)">📖 <?= htmlspecialchars($p['buku']) ?></div>
              <div style="font-size:11px;color:var(--gray-400);margin-top:3px">
                Kembali: <strong style="color:<?= $p['status']==='terlambat'?'#991B1B':'var(--gray-600)' ?>"><?= $p['tgl_kembali'] ?></strong>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
          <div style="padding:12px 16px">
            <button class="btn btn-ghost btn-sm w-full" style="justify-content:center">Lihat Semua Riwayat</button>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
</body>
</html>
