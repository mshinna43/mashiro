<?php
/**
 * Absensi Peserta Pelatihan / Ekstrakurikuler
 * File    : index.php
 * Tema    : Biru / Blue
 * Author  : Sistem Informasi Sekolah
 */

/* ── Data Kegiatan ── */
$kegiatan_list = ['Pelatihan OSIS','Pramuka','English Club','Basket','Paduan Suara'];
$kegiatan_aktif = $_GET['kegiatan'] ?? 'Pelatihan OSIS';

/* ── Data Peserta dengan Status per Kegiatan ── */
$peserta = [
    ['nis'=>'0812345','nama'=>'Ahmad Rizky Pratama', 'kelas'=>'8A','status'=>'hadir',  'waktu'=>'08:02'],
    ['nis'=>'0812346','nama'=>'Bella Sari Dewi',      'kelas'=>'8A','status'=>'hadir',  'waktu'=>'08:05'],
    ['nis'=>'0812347','nama'=>'Cahyo Wibowo',          'kelas'=>'8B','status'=>'absen',  'waktu'=>'—'],
    ['nis'=>'0812348','nama'=>'Dewi Rahayu Putri',     'kelas'=>'8B','status'=>'izin',   'waktu'=>'—'],
    ['nis'=>'0812349','nama'=>'Eko Firmansyah',        'kelas'=>'8C','status'=>'hadir',  'waktu'=>'08:10'],
    ['nis'=>'0812350','nama'=>'Fira Ananda Lestari',   'kelas'=>'8A','status'=>'hadir',  'waktu'=>'08:03'],
    ['nis'=>'0812351','nama'=>'Gilang Prayuda',         'kelas'=>'9A','status'=>'sakit',  'waktu'=>'—'],
    ['nis'=>'0812352','nama'=>'Hana Maharani',          'kelas'=>'9B','status'=>'hadir',  'waktu'=>'08:08'],
    ['nis'=>'0812353','nama'=>'Ivan Setiawan',          'kelas'=>'7A','status'=>'hadir',  'waktu'=>'08:06'],
    ['nis'=>'0812354','nama'=>'Jasmine Putri',          'kelas'=>'7B','status'=>'absen',  'waktu'=>'—'],
];

/* ── Hitung Rekap ── */
$hadir  = count(array_filter($peserta, fn($p) => $p['status'] === 'hadir'));
$absen  = count(array_filter($peserta, fn($p) => $p['status'] === 'absen'));
$izin   = count(array_filter($peserta, fn($p) => $p['status'] === 'izin'));
$sakit  = count(array_filter($peserta, fn($p) => $p['status'] === 'sakit'));
$total  = count($peserta);
$persen = $total > 0 ? round(($hadir / $total) * 100) : 0;

/* ── Persentase bar helper ── */
function pct(int $n, int $t): int { return $t > 0 ? (int)round($n / $t * 100) : 0; }

/* ── Status badge ── */
function badge_absen(string $status): string {
    return match($status) {
        'hadir'  => '<span class="badge badge-green">Hadir</span>',
        'absen'  => '<span class="badge badge-red">Absen</span>',
        'izin'   => '<span class="badge badge-amber">Izin</span>',
        'sakit'  => '<span class="badge badge-blue">Sakit</span>',
        default  => '<span class="badge badge-gray">—</span>',
    };
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Absensi Peserta — SMP Negeri 1 Contoh</title>
  <link rel="stylesheet" href="../shared.css">
  <style>
    :root {
      --accent       : #1D4ED8;
      --accent-hover : #1E40AF;
      --accent-light : rgba(29,78,216,.12);
      --accent-bg    : #EFF6FF;
    }
    .sidebar-brand .brand-icon { background: #DBEAFE; color: #1D4ED8; }
    .nav-item.active            { background: var(--accent); }
    .topbar-badge { background:#EFF6FF; color:#1D4ED8; font-size:11px; font-weight:600; padding:3px 10px; border-radius:99px; }

    /* ── Kegiatan Tabs ── */
    .kegiatan-tabs { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:24px; }
    .ktab {
      padding:8px 18px; border-radius:99px; font-size:13px; font-weight:600;
      cursor:pointer; border:1px solid var(--gray-200); color:var(--gray-500);
      background:#fff; transition:all .15s; text-decoration:none;
    }
    .ktab:hover  { border-color:var(--accent); color:var(--accent); }
    .ktab.active { background:var(--accent); color:#fff; border-color:var(--accent); }

    /* ── QR Scanner Box ── */
    .qr-box {
      background    : #fff;
      border        : 2px dashed var(--gray-200);
      border-radius : var(--radius-lg);
      padding       : 28px;
      text-align    : center;
      margin-bottom : 20px;
      transition    : border-color var(--transition);
    }
    .qr-box:hover { border-color: var(--accent); }
    .qr-icon   { font-size: 44px; margin-bottom: 10px; }
    .qr-title  { font-size: 15px; font-weight: 600; color: var(--gray-700); }
    .qr-sub    { font-size: 13px; color: var(--gray-400); margin-top: 4px; }

    /* ── Rekap Visual ── */
    .rekap-card { background:#fff; border-radius:var(--radius-lg); border:1px solid var(--gray-100); padding:20px; margin-bottom:20px; }
    .rekap-title { font-size:13px; font-weight:600; color:var(--gray-600); margin-bottom:16px; }
    .rekap-item { margin-bottom:12px; }
    .rekap-row { display:flex; justify-content:space-between; align-items:center; margin-bottom:4px; }
    .rekap-label { font-size:13px; color:var(--gray-600); }
    .rekap-num   { font-size:13px; font-weight:600; color:var(--gray-800); }
    .bar-track   { height:7px; background:var(--gray-100); border-radius:99px; overflow:hidden; }
    .bar-fill    { height:100%; border-radius:99px; }

    /* ── Two-col ── */
    .two-col { display:grid; grid-template-columns:1fr 300px; gap:20px; align-items:start; }
    @media (max-width:900px) { .two-col { grid-template-columns:1fr; } }
  </style>
</head>
<body>
<div class="page-wrapper">

  <!-- Sidebar -->
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="brand-icon">✅</div>
      <div class="brand-name">SMP Negeri 1 Contoh</div>
      <div class="brand-sub">Sistem Informasi Sekolah</div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section-label">Menu Utama</div>
      <a href="../ppdb/index.php"            class="nav-item"><div class="nav-icon">📋</div> PPDB</a>
      <a href="../perpustakaan/index.php"    class="nav-item"><div class="nav-icon">📚</div> Perpustakaan</a>
      <a href="index.php"                    class="nav-item active"><div class="nav-icon">✅</div> Absensi Peserta</a>
      <a href="../pembayaran-spp/index.php"  class="nav-item"><div class="nav-icon">💳</div> Pembayaran SPP</a>
      <a href="../absensi-siswa/index.php"   class="nav-item"><div class="nav-icon">👥</div> Absensi Siswa</a>
    </nav>
    <div class="sidebar-footer">v1.0.0 &nbsp;·&nbsp; TP 2025/2026</div>
  </aside>

  <!-- Konten -->
  <div class="main-content">
    <header class="topbar">
      <div class="topbar-title">Absensi Peserta</div>
      <div class="topbar-right">
        <span class="topbar-badge">🟢 Sesi Aktif</span>
        <span class="topbar-date"><?= date('d M Y, H:i') ?> WIB</span>
        <div class="avatar-sm" style="background:#DBEAFE;color:#1D4ED8;">GR</div>
      </div>
    </header>

    <div class="page-body">
      <div class="page-header flex items-center justify-between">
        <div>
          <h1 class="page-title">Kehadiran Kegiatan</h1>
          <p class="page-subtitle">Rekam kehadiran peserta pelatihan & ekstrakurikuler</p>
        </div>
        <div class="flex gap-2">
          <button class="btn btn-ghost">⬇ Export</button>
          <button class="btn btn-primary" style="background:var(--accent)">+ Input Manual</button>
        </div>
      </div>

      <!-- Tabs Kegiatan -->
      <div class="kegiatan-tabs">
        <?php foreach ($kegiatan_list as $kg): ?>
        <a href="?kegiatan=<?= urlencode($kg) ?>"
           class="ktab <?= $kegiatan_aktif===$kg?'active':'' ?>"><?= htmlspecialchars($kg) ?></a>
        <?php endforeach; ?>
      </div>

      <!-- Statistik -->
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon" style="background:#DCFCE7;color:#166534;">✅</div>
          <div class="stat-label">Hadir</div>
          <div class="stat-value" style="color:#166534"><?= $hadir ?></div>
          <div class="stat-desc"><?= $persen ?>% kehadiran</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#FEE2E2;color:#991B1B;">✗</div>
          <div class="stat-label">Absen</div>
          <div class="stat-value" style="color:#991B1B"><?= $absen ?></div>
          <div class="stat-desc">Tanpa keterangan</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#FEF3C7;color:#92400E;">📝</div>
          <div class="stat-label">Izin</div>
          <div class="stat-value" style="color:#92400E"><?= $izin ?></div>
          <div class="stat-desc">Ada surat izin</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#DBEAFE;color:#1E40AF;">🏥</div>
          <div class="stat-label">Sakit</div>
          <div class="stat-value" style="color:#1E40AF"><?= $sakit ?></div>
          <div class="stat-desc">Ada surat dokter</div>
        </div>
      </div>

      <div class="two-col">
        <!-- Tabel Absensi -->
        <div class="table-wrapper">
          <div class="table-header">
            <span class="table-title">📋 <?= htmlspecialchars($kegiatan_aktif) ?> — <?= date('d M Y') ?></span>
            <div class="progress" style="width:120px">
              <div class="progress-bar" style="width:<?= $persen ?>%;background:var(--accent)"></div>
            </div>
          </div>
          <table>
            <thead>
              <tr><th>NIS</th><th>Nama Peserta</th><th>Kelas</th><th>Waktu Hadir</th><th>Status</th><th>Aksi</th></tr>
            </thead>
            <tbody>
            <?php foreach ($peserta as $p): ?>
            <tr>
              <td><span style="font-family:var(--font-mono);font-size:11px;color:var(--gray-400)"><?= $p['nis'] ?></span></td>
              <td class="td-main"><?= htmlspecialchars($p['nama']) ?></td>
              <td><span class="badge badge-gray"><?= $p['kelas'] ?></span></td>
              <td style="font-family:var(--font-mono);font-size:13px"><?= $p['waktu'] ?></td>
              <td><?= badge_absen($p['status']) ?></td>
              <td>
                <select class="form-control" style="width:auto;padding:4px 8px;font-size:12px">
                  <option <?= $p['status']==='hadir' ?'selected':'' ?>>hadir</option>
                  <option <?= $p['status']==='absen' ?'selected':'' ?>>absen</option>
                  <option <?= $p['status']==='izin'  ?'selected':'' ?>>izin</option>
                  <option <?= $p['status']==='sakit' ?'selected':'' ?>>sakit</option>
                </select>
              </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <div class="pagination">
            <div class="page-btn active">1</div>
            <div class="page-info">Total <?= $total ?> peserta</div>
          </div>
        </div>

        <!-- Kolom Kanan: QR + Rekap -->
        <div>
          <div class="qr-box">
            <div class="qr-icon">📷</div>
            <div class="qr-title">Scan QR Peserta</div>
            <div class="qr-sub">Arahkan kamera ke kartu peserta untuk absensi otomatis</div>
            <button class="btn btn-primary mt-4" style="background:var(--accent);margin-top:14px">Aktifkan Kamera</button>
          </div>

          <div class="rekap-card">
            <div class="rekap-title">Rekap Kehadiran Hari Ini</div>
            <div class="rekap-item">
              <div class="rekap-row"><span class="rekap-label">Hadir</span><span class="rekap-num" style="color:#166534"><?= $hadir ?></span></div>
              <div class="bar-track"><div class="bar-fill" style="width:<?= pct($hadir,$total) ?>%;background:#22C55E"></div></div>
            </div>
            <div class="rekap-item">
              <div class="rekap-row"><span class="rekap-label">Absen</span><span class="rekap-num" style="color:#991B1B"><?= $absen ?></span></div>
              <div class="bar-track"><div class="bar-fill" style="width:<?= pct($absen,$total) ?>%;background:#EF4444"></div></div>
            </div>
            <div class="rekap-item">
              <div class="rekap-row"><span class="rekap-label">Izin</span><span class="rekap-num" style="color:#92400E"><?= $izin ?></span></div>
              <div class="bar-track"><div class="bar-fill" style="width:<?= pct($izin,$total) ?>%;background:#F59E0B"></div></div>
            </div>
            <div class="rekap-item">
              <div class="rekap-row"><span class="rekap-label">Sakit</span><span class="rekap-num" style="color:#1E40AF"><?= $sakit ?></span></div>
              <div class="bar-track"><div class="bar-fill" style="width:<?= pct($sakit,$total) ?>%;background:#3B82F6"></div></div>
            </div>
            <div style="margin-top:14px;padding-top:14px;border-top:1px solid var(--gray-100);text-align:center">
              <div style="font-size:32px;font-weight:700;color:var(--accent)"><?= $persen ?>%</div>
              <div style="font-size:12px;color:var(--gray-400)">Tingkat Kehadiran</div>
            </div>
          </div>

          <button class="btn btn-primary w-full" style="background:var(--accent);justify-content:center">
            💾 Simpan & Kirim Rekap
          </button>
        </div>
      </div>

    </div>
  </div>
</div>
</body>
</html>
