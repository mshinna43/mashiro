<?php
/**
 * PPDB - Penerimaan Peserta Didik Baru
 * File    : index.php
 * Tema    : Ungu / Violet
 * Author  : Sistem Informasi Sekolah
 */

/* ── Simulasi Data Pendaftar ── */
$pendaftar = [
    ['no'=>'PPDB-001','nama'=>'Ahmad Rizky Pratama',   'asal'=>'SDN 01 Merdeka',   'jalur'=>'Zonasi',    'status'=>'diterima',  'nilai'=>88.5,'tanggal'=>'10 Jun 2025'],
    ['no'=>'PPDB-002','nama'=>'Bella Sari Dewi',        'asal'=>'SDN 05 Harapan',   'jalur'=>'Prestasi',  'status'=>'diterima',  'nilai'=>92.0,'tanggal'=>'10 Jun 2025'],
    ['no'=>'PPDB-003','nama'=>'Cahyo Wibowo',           'asal'=>'SDN 12 Cendekia',  'jalur'=>'Zonasi',    'status'=>'verifikasi','nilai'=>79.0,'tanggal'=>'11 Jun 2025'],
    ['no'=>'PPDB-004','nama'=>'Dewi Rahayu Putri',      'asal'=>'MIS Al-Hidayah',   'jalur'=>'Afirmasi',  'status'=>'diterima',  'nilai'=>85.5,'tanggal'=>'11 Jun 2025'],
    ['no'=>'PPDB-005','nama'=>'Eko Firmansyah',         'asal'=>'SDN 03 Nusantara', 'jalur'=>'Zonasi',    'status'=>'ditolak',   'nilai'=>62.0,'tanggal'=>'12 Jun 2025'],
    ['no'=>'PPDB-006','nama'=>'Fira Ananda Lestari',    'asal'=>'SDN 07 Bintang',   'jalur'=>'Prestasi',  'status'=>'diterima',  'nilai'=>95.0,'tanggal'=>'12 Jun 2025'],
    ['no'=>'PPDB-007','nama'=>'Gilang Prayuda',         'asal'=>'SDIT Taqwa',       'jalur'=>'Zonasi',    'status'=>'verifikasi','nilai'=>75.5,'tanggal'=>'13 Jun 2025'],
    ['no'=>'PPDB-008','nama'=>'Hana Maharani',          'asal'=>'SDN 02 Sejahtera', 'jalur'=>'Afirmasi',  'status'=>'diterima',  'nilai'=>83.0,'tanggal'=>'13 Jun 2025'],
];

/* ── Filter & Search ── */
$filter_status = $_GET['status'] ?? 'semua';
$search        = strtolower(trim($_GET['q'] ?? ''));

$filtered = array_filter($pendaftar, function($d) use ($filter_status, $search) {
    $match_status = ($filter_status === 'semua') || ($d['status'] === $filter_status);
    $match_search = empty($search)
        || str_contains(strtolower($d['nama']), $search)
        || str_contains(strtolower($d['no']),   $search);
    return $match_status && $match_search;
});

/* ── Statistik ── */
$total      = count($pendaftar);
$diterima   = count(array_filter($pendaftar, fn($d) => $d['status'] === 'diterima'));
$ditolak    = count(array_filter($pendaftar, fn($d) => $d['status'] === 'ditolak'));
$verifikasi = count(array_filter($pendaftar, fn($d) => $d['status'] === 'verifikasi'));
$kuota      = 120;
$persen     = round(($diterima / $kuota) * 100);

/* ── Helper: badge status ── */
function badge_status(string $status): string {
    return match($status) {
        'diterima'   => '<span class="badge badge-green">Diterima</span>',
        'ditolak'    => '<span class="badge badge-red">Ditolak</span>',
        'verifikasi' => '<span class="badge badge-amber">Verifikasi</span>',
        default      => '<span class="badge badge-gray">—</span>',
    };
}

/* ── Helper: badge jalur ── */
function badge_jalur(string $jalur): string {
    return match($jalur) {
        'Zonasi'   => '<span class="badge badge-blue">Zonasi</span>',
        'Prestasi' => '<span class="badge badge-purple">Prestasi</span>',
        'Afirmasi' => '<span class="badge badge-teal">Afirmasi</span>',
        default    => '<span class="badge badge-gray">'.$jalur.'</span>',
    };
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PPDB — SMP Negeri 1 Contoh</title>
  <link rel="stylesheet" href="../shared.css">
  <style>
    /* ── Tema Aksen Ungu ── */
    :root {
      --accent       : #5B21B6;
      --accent-hover : #4C1D95;
      --accent-light : rgba(91,33,182,.12);
      --accent-bg    : #F5F3FF;
    }
    .sidebar-brand .brand-icon { background: #EDE9FE; color: #5B21B6; }
    .nav-item.active            { background: var(--accent); }
    .stat-icon-purple           { background: #EDE9FE; color: #5B21B6; }
    .stat-value-purple          { color: #5B21B6; }
    .topbar-badge {
      background : var(--accent-bg);
      color      : var(--accent);
      font-size  : 11px;
      font-weight: 600;
      padding    : 3px 10px;
      border-radius: 99px;
    }
    /* ── Kuota Progress ── */
    .kuota-card {
      background    : var(--accent);
      border-radius : var(--radius-lg);
      padding       : 20px 24px;
      color         : #fff;
      margin-bottom : 28px;
    }
    .kuota-title  { font-size: 12px; font-weight: 600; opacity: .75; text-transform: uppercase; letter-spacing: .5px; }
    .kuota-nums   { font-size: 32px; font-weight: 700; margin: 4px 0 14px; }
    .kuota-bar    { height: 8px; background: rgba(255,255,255,.25); border-radius: 99px; overflow: hidden; }
    .kuota-fill   { height: 100%; background: #fff; border-radius: 99px; }
    .kuota-sub    { font-size: 12px; opacity: .7; margin-top: 8px; }
    /* ── Filter Pills ── */
    .filter-pills { display: flex; gap: 6px; flex-wrap: wrap; }
    .pill {
      padding      : 6px 14px;
      border-radius: 99px;
      font-size    : 12px;
      font-weight  : 600;
      cursor       : pointer;
      border       : 1px solid var(--gray-200);
      color        : var(--gray-500);
      background   : #fff;
      transition   : all .15s;
      text-decoration: none;
    }
    .pill:hover  { border-color: var(--accent); color: var(--accent); }
    .pill.active { background: var(--accent); color: #fff; border-color: var(--accent); }
  </style>
</head>
<body>
<div class="page-wrapper">

  <!-- ═══ Sidebar ═══ -->
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="brand-icon">🎓</div>
      <div class="brand-name">SMP Negeri 1 Contoh</div>
      <div class="brand-sub">Sistem Informasi Sekolah</div>
    </div>

    <nav class="sidebar-nav">
      <div class="nav-section-label">Menu Utama</div>
      <a href="index.php" class="nav-item active">
        <div class="nav-icon">📋</div> PPDB
      </a>
      <a href="../perpustakaan/index.php" class="nav-item">
        <div class="nav-icon">📚</div> Perpustakaan
      </a>
      <a href="../absensi-peserta/index.php" class="nav-item">
        <div class="nav-icon">✅</div> Absensi Peserta
      </a>
      <a href="../pembayaran-spp/index.php" class="nav-item">
        <div class="nav-icon">💳</div> Pembayaran SPP
      </a>
      <a href="../absensi-siswa/index.php" class="nav-item">
        <div class="nav-icon">👥</div> Absensi Siswa
      </a>
    </nav>

    <div class="sidebar-footer">v1.0.0 &nbsp;·&nbsp; TP 2025/2026</div>
  </aside>

  <!-- ═══ Konten Utama ═══ -->
  <div class="main-content">

    <!-- Topbar -->
    <header class="topbar">
      <div class="topbar-title">Penerimaan Peserta Didik Baru</div>
      <div class="topbar-right">
        <span class="topbar-badge">PPDB 2025/2026</span>
        <span class="topbar-date"><?= date('d M Y') ?></span>
        <div class="avatar-sm" style="background:#EDE9FE;color:#5B21B6;">AD</div>
      </div>
    </header>

    <div class="page-body">

      <!-- Page Header -->
      <div class="page-header flex items-center justify-between">
        <div>
          <h1 class="page-title">Data Pendaftar</h1>
          <p class="page-subtitle">Rekap pendaftaran PPDB SMP Negeri 1 — Tahun Pelajaran 2025/2026</p>
        </div>
        <button class="btn btn-primary" style="background:var(--accent)">
          + Tambah Pendaftar
        </button>
      </div>

      <!-- Kuota Progress -->
      <div class="kuota-card">
        <div class="kuota-title">Kuota Siswa Baru</div>
        <div class="kuota-nums"><?= $diterima ?> <span style="font-size:18px;opacity:.7">/ <?= $kuota ?> siswa</span></div>
        <div class="kuota-bar">
          <div class="kuota-fill" style="width:<?= $persen ?>%"></div>
        </div>
        <div class="kuota-sub"><?= $persen ?>% kuota telah terisi &nbsp;·&nbsp; Sisa: <?= $kuota - $diterima ?> kursi</div>
      </div>

      <!-- Statistik -->
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon stat-icon-purple">📋</div>
          <div class="stat-label">Total Pendaftar</div>
          <div class="stat-value stat-value-purple"><?= $total ?></div>
          <div class="stat-desc">Semua jalur pendaftaran</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#DCFCE7;color:#166534;">✅</div>
          <div class="stat-label">Diterima</div>
          <div class="stat-value" style="color:#166534"><?= $diterima ?></div>
          <div class="stat-desc">Lolos seleksi</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#FEF3C7;color:#92400E;">⏳</div>
          <div class="stat-label">Verifikasi</div>
          <div class="stat-value" style="color:#92400E"><?= $verifikasi ?></div>
          <div class="stat-desc">Menunggu verifikasi</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon" style="background:#FEE2E2;color:#991B1B;">✗</div>
          <div class="stat-label">Ditolak</div>
          <div class="stat-value" style="color:#991B1B"><?= $ditolak ?></div>
          <div class="stat-desc">Tidak memenuhi syarat</div>
        </div>
      </div>

      <!-- Tabel Pendaftar -->
      <div class="table-wrapper">
        <div class="table-header">
          <span class="table-title">Daftar Pendaftar</span>
          <div class="flex gap-3 items-center flex-wrap">
            <!-- Filter Status -->
            <div class="filter-pills">
              <?php
              $pills = ['semua'=>'Semua','diterima'=>'Diterima','verifikasi'=>'Verifikasi','ditolak'=>'Ditolak'];
              foreach ($pills as $val => $label):
                $active = ($filter_status === $val) ? 'active' : '';
              ?>
              <a href="?status=<?= $val ?>&q=<?= htmlspecialchars($search) ?>"
                 class="pill <?= $active ?>"><?= $label ?></a>
              <?php endforeach; ?>
            </div>
            <!-- Search -->
            <form method="GET" style="display:contents">
              <input type="hidden" name="status" value="<?= htmlspecialchars($filter_status) ?>">
              <div class="search-wrapper">
                <span class="search-icon">🔍</span>
                <input type="text" name="q" class="search-input"
                       placeholder="Cari nama / no. daftar..."
                       value="<?= htmlspecialchars($search) ?>">
              </div>
            </form>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th>No. Daftar</th>
              <th>Nama Lengkap</th>
              <th>Asal Sekolah</th>
              <th>Jalur</th>
              <th>Nilai</th>
              <th>Tanggal</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
          <?php if (empty($filtered)): ?>
            <tr>
              <td colspan="8" style="text-align:center;padding:40px;color:var(--gray-400);">
                Tidak ada data yang ditemukan.
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($filtered as $d): ?>
            <tr>
              <td><span style="font-family:var(--font-mono);font-size:12px;color:var(--gray-400)"><?= htmlspecialchars($d['no']) ?></span></td>
              <td class="td-main"><?= htmlspecialchars($d['nama']) ?></td>
              <td><?= htmlspecialchars($d['asal']) ?></td>
              <td><?= badge_jalur($d['jalur']) ?></td>
              <td><strong><?= number_format($d['nilai'], 1) ?></strong></td>
              <td class="text-muted text-sm"><?= $d['tanggal'] ?></td>
              <td><?= badge_status($d['status']) ?></td>
              <td>
                <button class="btn btn-ghost btn-sm">Detail</button>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>

        <div class="pagination">
          <div class="page-btn active">1</div>
          <div class="page-btn">2</div>
          <div class="page-btn">3</div>
          <div class="page-info">Menampilkan <?= count($filtered) ?> dari <?= $total ?> data</div>
        </div>
      </div>

    </div><!-- /page-body -->
  </div><!-- /main-content -->
</div><!-- /page-wrapper -->
</body>
</html>
