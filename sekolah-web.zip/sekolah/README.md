# Sistem Informasi Sekolah — SMP Negeri 1 Contoh
## Panduan Instalasi & Penggunaan

---

## Struktur Proyek

```
sekolah/
├── shared.css                   ← CSS bersama (variabel, komponen, layout)
│
├── ppdb/
│   └── index.php               ← PPDB (tema: Ungu)
│
├── perpustakaan/
│   └── index.php               ← Perpustakaan (tema: Teal)
│
├── absensi-peserta/
│   └── index.php               ← Absensi Peserta (tema: Biru)
│
├── pembayaran-spp/
│   └── index.php               ← Pembayaran SPP (tema: Amber)
│
└── absensi-siswa/
    └── index.php               ← Absensi Siswa (tema: Hijau)
```

---

## Cara Menjalankan

### Menggunakan PHP Built-in Server (Lokal)
```bash
# Masuk ke folder proyek
cd sekolah/

# Jalankan server pada port 8000
php -S localhost:8000

# Buka di browser:
# http://localhost:8000/ppdb/
# http://localhost:8000/perpustakaan/
# http://localhost:8000/absensi-peserta/
# http://localhost:8000/pembayaran-spp/
# http://localhost:8000/absensi-siswa/
```

### Menggunakan XAMPP / Laragon
1. Salin seluruh folder `sekolah/` ke dalam `htdocs/` (XAMPP)
   atau `www/` (Laragon)
2. Jalankan Apache
3. Buka `http://localhost/sekolah/ppdb/`

---

## Teknologi

| Komponen   | Teknologi                                  |
|------------|--------------------------------------------|
| Backend    | PHP 8.1+ (native, tanpa framework)         |
| Frontend   | HTML5 + CSS3 (custom, tanpa library CSS)   |
| Font       | Google Fonts (Plus Jakarta Sans, DM Mono)  |
| Database   | — (data dummy, siap diganti PDO/MySQLi)    |

---

## Koneksi Database (Opsional)

Ganti data array dummy di setiap `index.php` dengan query PDO:

```php
// Contoh koneksi PDO
$pdo = new PDO('mysql:host=localhost;dbname=sekolah', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Contoh query
$stmt = $pdo->query('SELECT * FROM pendaftar ORDER BY created_at DESC');
$pendaftar = $stmt->fetchAll(PDO::FETCH_ASSOC);
```

---

## Standar Kode yang Diterapkan

- Setiap file dibuka dengan docblock (nama, tema, author)
- Logika PHP dipisah dari HTML (bagian atas = PHP, bawah = HTML)
- Penamaan variabel dalam bahasa Indonesia yang konsisten
- Helper function untuk badge/format diletakkan sebelum HTML
- CSS menggunakan custom properties (variabel) untuk konsistensi tema
- Struktur HTML: sidebar → main → topbar → page-body
- Komentar bagian menggunakan `/* ── Label ── */`
